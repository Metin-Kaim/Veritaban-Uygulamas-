﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace postgreurunproje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localhost;port=5432;Database=dburunler;user Id=postgres;password=Laboratuvar26");

        private void btnListele_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from kategoriler order by kat_id";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into kategoriler (kat_id,kat_ad) values (@p1,@p2)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtKatID.Text));
            komut1.Parameters.AddWithValue("@p2", txtKatAd.Text);
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Kategori eklendi.");
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut2 = new NpgsqlCommand("Delete from kategoriler where kat_id=@p1", baglanti);
            komut2.Parameters.AddWithValue("@p1", int.Parse(txtKatID.Text));
            komut2.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("silme gerçekleşti");
        }

        private void btnGüncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update kategoriler set kat_ad=@p1 where kat_id=@p2", baglanti);

            komut3.Parameters.AddWithValue("@p2", int.Parse(txtKatID.Text));
            komut3.Parameters.AddWithValue("@p1", txtKatAd.Text);
            komut3.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("güncellendi");
        }
    }
}
